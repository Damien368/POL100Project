Bounty System FAQ:

Q: how does it work:
A: when a player dies, any other player that participated
   in the attack may be reported for the murder. For each
   participant the player chooses to report for the murder,
   he will also be prompted to post a bounty. Bounties are
   subtracted from the player's bank box, and may not exceed
   the total amount of gold a player has in his bank box.
   Once a player has placed a bounty on his murderer, if
   the murderer's total bounty is within the top 50 posted
   bounties on the shard, his name will appear on the bounty
   board.

Q: How do I collect a bounty?
A: Any player may turn the head of another player in to any
   town guard. The guard will check to see if a bounty exists
   (actually a third party script will do this, but it is
   transparent to the players) for the head that was turned
   in, and award a bounty straight to the bank box of the
   player that turned in the bounty.

Q: If I get a bounty, will it stick around forever?
A: All bounties expire 2 weeks after placement. If you dont
   incurr any additional bounties within that two week period,
   then your bounty will be removed from the list, and guards
   will not reward any bounties on your head. Once a bounty is
   claimed, it will be removed from the list.

Q: Are there any penalties for having a bounty on my head?
A: Currently there are no penalties except the greed of other
   players. >:]