[![Build Status](https://travis-ci.org/polserver/ClassicDistro.svg?branch=master)](https://travis-ci.org/polserver/ClassicDistro)

# POL-Distro

A basic working set of scripts used by the POL UO emulator.
This is mostly an upgrade of the POL 0.95 Distro to work with current POL versions. It is a little more than that because I have included some of the scripts from the unfinished 0.97 Distro started by Austin started. His version of the "info" command is just one example.

Some of the code needs cleaned-up but it does compile. You can drop in the appropriate Core and after editing the proper config files you'll have a basic working server. There aren't many special scripts. I have tried to produce a Distro in the spirit of the original POL project which was a no-frills basic working shard that you could take and mold it into your world. That's the way the original POL developers had intended it to be. All of the Distro contained in the initial release is taken from my shard because my shard is based on the POL 0.95 Distro.

There is a growing collection of documentation in the \docs\Additional Docs directory. I will add to it as time permits.
